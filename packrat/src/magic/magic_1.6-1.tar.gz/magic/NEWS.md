# freegroup 1.6-0

- emphasis on high-dimensional arrays rather than magic hypercubes
- sticker now in vignette
- new README
- minor bugfixes
