library(testthat)
library(BiocManager)

test_check("BiocManager")
